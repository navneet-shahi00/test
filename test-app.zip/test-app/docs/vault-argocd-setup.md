# Vault + ArgoCD Setup Guide

## Table of Contents
1. [Architecture Overview](#architecture-overview)
2. [Prerequisites](#prerequisites)
3. [Step 1 — Install HashiCorp Vault](#step-1--install-hashicorp-vault)
4. [Step 2 — Initialize and Unseal Vault](#step-2--initialize-and-unseal-vault)
5. [Step 3 — Configure Vault](#step-3--configure-vault)
6. [Step 4 — Store Secrets in Vault](#step-4--store-secrets-in-vault)
7. [Step 5 — Connect ArgoCD to Private Repo](#step-5--connect-argocd-to-private-repo)
8. [Step 6 — New Applications (About to Deploy)](#step-6--new-applications-about-to-deploy)
9. [Step 7 — Existing Applications (Already Deployed)](#step-7--existing-applications-already-deployed)
10. [Step 8 — Install External Secrets Operator (GHCR Pull Secret)](#step-8--install-external-secrets-operator-ghcr-pull-secret)
11. [Verification](#verification)
12. [Troubleshooting](#troubleshooting)

---

## Architecture Overview

```
Developer → pushes code → GitHub (private repo)
                              ↓
                    GitHub Actions (CI)
                    - builds Docker image
                    - pushes to GHCR (private registry)
                    - updates image tag in k8s/deployment.yaml
                              ↓
                    ArgoCD watches repo
                    - detects manifest change
                    - syncs to Kubernetes cluster
                              ↓
                    Kubernetes creates Pod
                    - Vault Agent Injector webhook intercepts
                    - injects vault-agent-init + vault-agent sidecar
                    - secrets written to /vault/secrets/config
                    - app reads secrets as env vars
```

---

## Prerequisites

- Kubernetes cluster running (Minikube or cloud)
- `kubectl` configured
- `helm` installed
- ArgoCD installed and accessible via browser
- GitHub account with a private repo
- GitHub PAT with `repo` + `write:packages` + `read:packages` scopes

---

## Step 1 — Install HashiCorp Vault

```bash
helm repo add hashicorp https://helm.releases.hashicorp.com
helm repo update

helm install vault hashicorp/vault \
  -n vault --create-namespace \
  -f k8s/vault/values.yaml
```

Wait for the pod to appear (it will show `0/1` until initialized):
```bash
kubectl get pods -n vault -w
```

---

## Step 2 — Initialize and Unseal Vault

> Run this only once. Save the Unseal Key and Root Token — they cannot be recovered.

```bash
# Initialize
kubectl exec -it vault-0 -n vault -- vault operator init \
  -key-shares=1 -key-threshold=1

# Unseal (use the Unseal Key from above)
kubectl exec -it vault-0 -n vault -- vault operator unseal <UNSEAL_KEY>
```

Verify Vault is unsealed:
```bash
kubectl exec -it vault-0 -n vault -- vault status
# Sealed: false  ← expected
```

> **Important (Minikube only):** Vault seals itself every time the pod restarts.
> You must re-run the unseal command after each restart. For production,
> configure Auto Unseal with a cloud KMS.

---

## Step 3 — Configure Vault

Open a shell inside the Vault pod:
```bash
kubectl exec -it vault-0 -n vault -- /bin/sh
```

Run all configuration commands inside the pod:

```sh
# Login with Root Token
vault login <ROOT_TOKEN>

# Enable KV v2 secrets engine
vault secrets enable -path=secret kv-v2

# Enable Kubernetes auth method
vault auth enable kubernetes

# Configure Kubernetes auth (uses in-cluster service account)
vault write auth/kubernetes/config \
  kubernetes_host="https://$KUBERNETES_PORT_443_TCP_ADDR:443"

# Create policy — grants read access to app secrets
vault policy write test-app-policy - <<EOF
path "secret/data/test-app" {
  capabilities = ["read"]
}
path "secret/data/ghcr" {
  capabilities = ["read"]
}
path "auth/token/renew-self" {
  capabilities = ["update"]
}
EOF

# Create Kubernetes auth role — binds policy to app's ServiceAccount
vault write auth/kubernetes/role/test-app \
  bound_service_account_names=test-app \
  bound_service_account_namespaces=test-app \
  policies=test-app-policy \
  ttl=1h

exit
```

---

## Step 4 — Store Secrets in Vault

```bash
# App secrets
kubectl exec -it vault-0 -n vault -- vault kv put secret/test-app \
  DATABASE_URL="postgresql://user:pass@host:5432/db" \
  API_KEY="sk-your-api-key" \
  JWT_SECRET="your-random-string" \
  REDIS_URL="redis://:pass@host:6379/0"

# GHCR credentials (used by External Secrets Operator)
kubectl exec -it vault-0 -n vault -- vault kv put secret/ghcr \
  username="navneet072300" \
  password="ghp_YOUR_PAT"
```

Verify:
```bash
kubectl exec -it vault-0 -n vault -- vault kv get secret/test-app
kubectl exec -it vault-0 -n vault -- vault kv get secret/ghcr
```

> If Vault restarts (Minikube), you must unseal it and re-write secrets.
> Production Vault with persistent storage retains secrets across restarts.

---

## Step 5 — Connect ArgoCD to Private Repo

### 5.1 — Add the GitHub repo

1. Open ArgoCD UI → **Settings → Repositories → Connect Repo**
2. Choose **HTTPS**
3. Fill in:
   - **Repository URL**: `https://github.com/YOUR_ORG/YOUR_REPO.git`
   - **Username**: `YOUR_GITHUB_USERNAME`
   - **Password**: `ghp_YOUR_PAT`
4. Click **Connect**
5. Verify the **Connection Status** shows `Successful`

> The PAT must have `repo` scope to access private repositories.

### 5.2 — Create the ArgoCD Application

1. Go to **Applications → New App**
2. Fill in:
   - **Application Name**: `test-app`
   - **Project**: `default`
   - **Sync Policy**: `Manual`
   - **Repository URL**: your repo URL
   - **Revision**: `main`
   - **Path**: `k8s`
   - **Cluster**: `https://kubernetes.default.svc`
   - **Namespace**: `test-app`
3. Click **Create**

### 5.3 — Sync the Application

1. Open **Applications → test-app**
2. Click **Sync** → **Synchronize**
3. Watch resources turn green

---

## Step 6 — New Applications (About to Deploy)

Use this section when deploying a brand new application with Vault from the start.

### 6.1 — Kubernetes manifests required

Create these files directly in your GitHub repo under the `k8s/` directory
(click **Add file → Create new file** in the GitHub UI):

**`k8s/namespace.yaml`**
```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: my-app
```

**`k8s/serviceaccount.yaml`**
```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: my-app
  namespace: my-app
```

**`k8s/deployment.yaml`** — add Vault annotations to the pod template:
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
  namespace: my-app
spec:
  replicas: 2
  selector:
    matchLabels:
      app: my-app
  template:
    metadata:
      labels:
        app: my-app
      annotations:
        # Vault Agent Injector annotations
        vault.hashicorp.com/agent-inject: "true"
        vault.hashicorp.com/role: "my-app"
        vault.hashicorp.com/agent-inject-secret-config: "secret/data/my-app"
        vault.hashicorp.com/agent-inject-template-config: |
          {{- with secret "secret/data/my-app" -}}
          export DATABASE_URL="{{ .Data.data.DATABASE_URL }}"
          export API_KEY="{{ .Data.data.API_KEY }}"
          {{- end }}
        vault.hashicorp.com/agent-pre-populate-only: "false"
    spec:
      serviceAccountName: my-app
      imagePullSecrets:
        - name: ghcr-pull-secret
      containers:
        - name: my-app
          image: ghcr.io/YOUR_ORG/my-app:latest
          command: ["/bin/sh", "-c"]
          args:
            - |
              source /vault/secrets/config
              node src/index.js   # or your app start command
          ports:
            - containerPort: 3000
          env:
            - name: PORT
              value: "3000"
```

### 6.2 — Pre-deployment steps (run once on cluster)

> Only the GHCR pull secret is created manually — it contains real credentials
> and must never be committed to git. Everything else is committed to GitHub
> and synced via ArgoCD.

```bash
kubectl create secret docker-registry ghcr-pull-secret \
  -n my-app \
  --docker-server=ghcr.io \
  --docker-username=YOUR_GITHUB_USERNAME \
  --docker-password=ghp_YOUR_PAT
```

### 6.3 — Register the app in Vault

```bash
kubectl exec -it vault-0 -n vault -- /bin/sh
```
```sh
vault login <ROOT_TOKEN>

# Store app secrets
vault kv put secret/my-app \
  DATABASE_URL="postgresql://..." \
  API_KEY="sk-..."

# Create policy
vault policy write my-app-policy - <<EOF
path "secret/data/my-app" {
  capabilities = ["read"]
}
path "auth/token/renew-self" {
  capabilities = ["update"]
}
EOF

# Create Kubernetes auth role
vault write auth/kubernetes/role/my-app \
  bound_service_account_names=my-app \
  bound_service_account_namespaces=my-app \
  policies=my-app-policy \
  ttl=1h
exit
```

### 6.4 — Deploy via ArgoCD UI

Once all manifest files are committed to GitHub:

1. Open ArgoCD UI → **Applications → my-app**
2. Click **Refresh** (picks up latest changes from GitHub)
3. Click **Sync → Synchronize**
4. Watch all resources turn green — Namespace, ServiceAccount, Service, Deployment

---

## Step 7 — Existing Applications (Already Deployed)

Use this section when your application is already running and you want to connect it to Vault without access to the application directory.

### 7.1 — Add Vault annotations to the existing Deployment

Go to your GitHub repo → navigate to `k8s/deployment.yaml` → click **Edit (pencil icon)**.

Add these annotations under `spec.template.metadata.annotations`:

```yaml
vault.hashicorp.com/agent-inject: "true"
vault.hashicorp.com/role: "my-app"
vault.hashicorp.com/agent-inject-secret-config: "secret/data/my-app"
vault.hashicorp.com/agent-inject-template-config: |
  {{- with secret "secret/data/my-app" -}}
  export DATABASE_URL="{{ .Data.data.DATABASE_URL }}"
  export API_KEY="{{ .Data.data.API_KEY }}"
  {{- end }}
vault.hashicorp.com/agent-pre-populate-only: "false"
```

Also add `serviceAccountName` under `spec.template.spec`:
```yaml
serviceAccountName: my-app
```

Also update the container command to source the Vault secrets file:
```yaml
command: ["/bin/sh", "-c"]
args:
  - |
    source /vault/secrets/config
    <YOUR_ORIGINAL_START_COMMAND>
```

Commit the changes directly on GitHub → go to **ArgoCD UI → Sync**.

### 7.2 — Ensure ServiceAccount exists

Go to your GitHub repo → navigate to `k8s/serviceaccount.yaml` → click **Edit (pencil icon)**.

Make sure the file contains:
```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: my-app
  namespace: my-app
```

Commit the changes directly on GitHub → go to **ArgoCD UI → Sync**.

### 7.3 — Register the app in Vault (same as new app)

```bash
kubectl exec -it vault-0 -n vault -- /bin/sh
```
```sh
vault login <ROOT_TOKEN>

vault kv put secret/my-app \
  DATABASE_URL="postgresql://..." \
  API_KEY="sk-..."

vault policy write my-app-policy - <<EOF
path "secret/data/my-app" {
  capabilities = ["read"]
}
path "auth/token/renew-self" {
  capabilities = ["update"]
}
EOF

vault write auth/kubernetes/role/my-app \
  bound_service_account_names=my-app \
  bound_service_account_namespaces=my-app \
  policies=my-app-policy \
  ttl=1h
exit
```

### 7.4 — Update the app to read Vault secrets

The app container must source the injected file. Patch the container command:

```bash
kubectl patch deployment my-app -n my-app --patch '
{
  "spec": {
    "template": {
      "spec": {
        "containers": [{
          "name": "my-app",
          "command": ["/bin/sh", "-c"],
          "args": ["source /vault/secrets/config && <YOUR_ORIGINAL_START_COMMAND>"]
        }]
      }
    }
  }
}'
```

### 7.5 — Sync via ArgoCD UI

All manifest changes are made directly on GitHub. Once committed:

1. Open **ArgoCD UI → Applications → my-app**
2. Click **Refresh** (to pick up latest changes from GitHub)
3. Click **Sync → Synchronize**
4. Watch all resources turn green

### 7.6 — Update repoURL if wrong (UI only)

If ArgoCD shows the wrong repo URL:
1. Open **Applications → my-app → App Details** (top right)
2. Click **Edit**
3. Update the **Repo URL** field
4. Click **Save**
5. Click **Sync → Synchronize**

---

## Step 8 — Install External Secrets Operator (GHCR Pull Secret)

ESO syncs the GHCR credentials from Vault into a Kubernetes `imagePullSecret` automatically.

```bash
helm repo add external-secrets https://charts.external-secrets.io
helm repo update

helm install external-secrets external-secrets/external-secrets \
  -n external-secrets --create-namespace \
  --set installCRDs=true
```

Grant ArgoCD permission to manage ESO resources:
```bash
kubectl create clusterrole argocd-externalsecrets \
  --verb=get,list,watch,create,update,patch,delete \
  --resource=externalsecrets.external-secrets.io,secretstores.external-secrets.io

kubectl create clusterrolebinding argocd-externalsecrets \
  --clusterrole=argocd-externalsecrets \
  --serviceaccount=argocd:argocd-application-controller
```

The `k8s/external-secrets/` manifests will then:
1. `secret-store.yaml` — connect ESO to Vault using Kubernetes auth
2. `ghcr-external-secret.yaml` — read `secret/ghcr` from Vault and create `ghcr-pull-secret`

---

## Verification

### Check pods are running with Vault sidecar
```bash
kubectl get pods -n my-app
# READY column should show 2/2 (app + vault-agent)
```

### Check secrets are injected
```bash
kubectl exec -it <pod-name> -n my-app -c my-app -- cat /vault/secrets/config
```

### Check env vars are loaded
```bash
kubectl exec -it <pod-name> -n my-app -c my-app -- \
  /bin/sh -c 'source /vault/secrets/config && env | grep -E "DATABASE_URL|API_KEY"'
```

### Check Vault agent logs
```bash
kubectl logs <pod-name> -n my-app -c vault-agent
```

### Check ExternalSecret sync status
```bash
kubectl get externalsecret -n my-app
# READY column should show: True
```

### Test the application
```bash
kubectl port-forward svc/my-app -n my-app 3000:80 &
curl http://localhost:3000/health
```

---

## Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `no secret exists at secret/data/...` | Vault restarted and lost data | Unseal Vault and re-write secrets |
| `permission denied` | Not logged in to Vault | `vault login <ROOT_TOKEN>` |
| `unauthorized` on image pull | `ghcr-pull-secret` missing | Create it manually with `kubectl create secret docker-registry` |
| `no matching manifest for linux/arm64` | Image built for amd64 only | Add `platforms: linux/amd64,linux/arm64` to CI workflow |
| `authentication required: Repository not found` | Wrong PAT scope or repo credentials missing | Go to **Settings → Repositories** → remove and re-add repo with PAT having `repo` scope |
| `illegal base64 data` | Secret YAML has placeholder value in repo | Remove the file from git, create the secret manually with `kubectl` |
| `Init:0/1` stuck | Vault agent can't fetch secret | Check `kubectl logs <pod> -c vault-agent-init` |
| Vault sealed after restart | File storage on Minikube is ephemeral | Run `vault operator unseal` after every Minikube restart |
