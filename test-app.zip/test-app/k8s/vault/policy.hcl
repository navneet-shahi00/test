# Vault policy for the test-app
# Grants the app read-only access to its own secrets path only.
#
# Apply with:
#   vault policy write test-app-policy k8s/vault/policy.hcl

path "secret/data/test-app" {
  capabilities = ["read"]
}

path "secret/data/ghcr" {
  capabilities = ["read"]
}

# Allow the app to renew its own token
path "auth/token/renew-self" {
  capabilities = ["update"]
}
