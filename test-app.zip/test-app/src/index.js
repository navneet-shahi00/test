const express = require('express');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.get('/health', (req, res) => {
  res.json({ status: 'ok', version: process.env.APP_VERSION || 'local' });
});

app.get('/', (req, res) => {
  res.json({ message: 'Hello from test-app!' });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
